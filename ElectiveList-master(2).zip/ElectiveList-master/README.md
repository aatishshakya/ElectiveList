## Elective Student list

In order to run the project, you'll need
1. node.js
2. WAMP/LAMP/XAMP (Apache, MySQL)

#### Steps
1. After cloning the repo, you will need to install the node modules via npm install
2. Start the apache server (WAMP/LAMP/XAMP)
3. Create a database 'elective' and import the tables from file placed inside 'Database Tables' folder
4. Run the project via nodemon app.js
